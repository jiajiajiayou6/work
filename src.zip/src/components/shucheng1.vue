<template>
    <div id="spo1">
        <!-- 我是书城 -->
    </div>
</template>

<script>
export default {
    name: 'WorkShucheng1',

    data() {
        return {

        };
    },

    mounted() {

    },

    methods: {

    },
};
</script>

<style scoped>

</style>