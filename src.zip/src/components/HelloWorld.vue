<template>
  <div id="app">
    <div id="top">
      <div id="top-top">
        <b>微信读书</b>
      </div>
      <div id="top-content">
        <svg t="1691066671752" class="icon1" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
          p-id="2294" width="32" height="32">
          <path
            d="M384 128c140.8 0 256 115.2 256 256S524.8 640 384 640 128 524.8 128 384s115.2-256 256-256m0-64C207.2 64 64 207.2 64 384s143.2 320 320 320 320-143.2 320-320S560.8 64 384 64z m294.4 569.6l-45.6 45.6 272 272 45.6-45.6-272-272z"
            p-id="2295" fill="#8a8a8a"></path>
        </svg>
        <input type="text" name="text" id="text" placeholder="搜索">
      </div>
      <div id="top-buttom">
        <div id="top-buttom-top">
          <img class="w1"
            src="https://img1.baidu.com/it/u=3129770633,3933811923&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500" alt="">
          <span class="w2">三七二十一</span>
          <span class="w3">体验卡今日到期</span>
          <a class="w4" href="#">反馈</a>
        </div>
        <div id="top-buttom-buttom">
          <div id="t1">
            <img class="w5"
              src="https://weread-1258476243.file.myqcloud.com/weread/cover/25/cpplatform_8numzl8erzinxvfsk3p9jv/t6_cpplatform_8numzl8erzinxvfsk3p9jv1685508354.jpg"
              alt="">
          </div>
        </div>
      </div>
    </div>
    <div id="content">
      <student>
        <div>
          <ul class="yl1">
            <li style="color: rgb(88, 143, 226);">推荐</li>
            <li>分类</li>
            <li>排行</li>
            <li>文学</li>
          </ul>
          <div class="yl2">
            <div>
              <ul>
                <li class="ul-li1">
                  <div style="float: left;">
                    <img class="all1"
                      src="https://weread-1258476243.file.myqcloud.com/weread/cover/55/cpplatform_2thuj2jlv1odkiylmdlcjr/t6_cpplatform_2thuj2jlv1odkiylmdlcjr1689825647.jpg"
                      alt="">
                  </div>
                  <div style="float: left;">
                    <p style="font-size: 20px;margin-left: 20px;"><b>麻衣神算子</b></p>
                    <p style="font-size: 15px;margin-left: 20px;">骑马钓鱼|推荐值78.5%</p>
                    <p style="font-size: 15px;margin-left: 20px;">大家都在读</p>
                  </div>
                </li>
                <li class="ul-li1">
                  <div style="float: left;">
                    <img class="all1"
                      src="https://weread-1258476243.file.myqcloud.com/weread/cover/55/cpplatform_2thuj2jlv1odkiylmdlcjr/t6_cpplatform_2thuj2jlv1odkiylmdlcjr1689825647.jpg"
                      alt="">
                  </div>
                  <div style="float: left;">
                    <p style="font-size: 20px;margin-left: 20px;"><b>麻衣神算子</b></p>
                    <p style="font-size: 15px;margin-left: 20px;">骑马钓鱼|推荐值78.5%</p>
                    <p style="font-size: 15px;margin-left: 20px;">大家都在读</p>
                  </div>
                </li>
                <li class="ul-li1">
                  <div style="float: left;">
                    <img class="all1"
                      src="https://weread-1258476243.file.myqcloud.com/weread/cover/55/cpplatform_2thuj2jlv1odkiylmdlcjr/t6_cpplatform_2thuj2jlv1odkiylmdlcjr1689825647.jpg"
                      alt="">
                  </div>
                  <div style="float: left;">
                    <p style="font-size: 20px;margin-left: 20px;"><b>麻衣神算子</b></p>
                    <p style="font-size: 15px;margin-left: 20px;">骑马钓鱼|推荐值78.5%</p>
                    <p style="font-size: 15px;margin-left: 20px;">大家都在读</p>
                  </div>
                </li>
                <li class="ul-li1">
                  <div style="float: left;">
                    <img class="all1"
                      src="https://weread-1258476243.file.myqcloud.com/weread/cover/55/cpplatform_2thuj2jlv1odkiylmdlcjr/t6_cpplatform_2thuj2jlv1odkiylmdlcjr1689825647.jpg"
                      alt="">
                  </div>
                  <div style="float: left;">
                    <p style="font-size: 20px;margin-left: 20px;"><b>麻衣神算子</b></p>
                    <p style="font-size: 15px;margin-left: 20px;">骑马钓鱼|推荐值78.5%</p>
                    <p style="font-size: 15px;margin-left: 20px;">大家都在读</p>
                  </div>
                </li>
                <li class="ul-li1">
                  <div style="float: left;">
                    <img class="all1"
                      src="https://weread-1258476243.file.myqcloud.com/weread/cover/55/cpplatform_2thuj2jlv1odkiylmdlcjr/t6_cpplatform_2thuj2jlv1odkiylmdlcjr1689825647.jpg"
                      alt="">
                  </div>
                  <div style="float: left;">
                    <p style="font-size: 20px;margin-left: 20px;"><b>麻衣神算子</b></p>
                    <p style="font-size: 15px;margin-left: 20px;">骑马钓鱼|推荐值78.5%</p>
                    <p style="font-size: 15px;margin-left: 20px;">大家都在读</p>
                  </div>
                </li>
                <li class="ul-li1">
                  <div style="float: left;">
                    <img class="all1"
                      src="https://weread-1258476243.file.myqcloud.com/weread/cover/55/cpplatform_2thuj2jlv1odkiylmdlcjr/t6_cpplatform_2thuj2jlv1odkiylmdlcjr1689825647.jpg"
                      alt="">
                  </div>
                  <div style="float: left;">
                    <p style="font-size: 20px;margin-left: 20px;"><b>麻衣神算子</b></p>
                    <p style="font-size: 15px;margin-left: 20px;">骑马钓鱼|推荐值78.5%</p>
                    <p style="font-size: 15px;margin-left: 20px;">大家都在读</p>
                  </div>
                </li>
              </ul>
            </div>
            <!-- <div></div>
            <div></div>
            <div>内容-3</div>
            <div>内容-4</div> -->
          </div>
        </div>
      </student>
    </div>
    <div id="buttom">
      <dl>
        <dd>
          <svg t="1691067339992" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
            p-id="3659" width="32" height="32">
            <path
              d="M783.36 307.2c20.48-20.48 35.84-43.52 46.08-69.12 20.48-48.64 17.92-97.28-5.12-135.68C778.24 20.48 660.48 2.56 563.2 58.88c-33.28 20.48-61.44 46.08-81.92 76.8-15.36-25.6-35.84-48.64-61.44-61.44-35.84-20.48-76.8-25.6-115.2-12.8-71.68 28.16-104.96 120.32-74.24 204.8 7.68 15.36 15.36 28.16 23.04 40.96h-7.68c-115.2 0-207.36 97.28-207.36 217.6v256c0 120.32 92.16 217.6 207.36 217.6h532.48c115.2 0 207.36-97.28 207.36-217.6v-256c0-120.32-89.6-215.04-202.24-217.6z m-248.32-107.52c12.8-28.16 35.84-53.76 66.56-71.68 25.6-15.36 53.76-23.04 79.36-23.04 33.28 0 61.44 12.8 76.8 35.84 10.24 17.92 10.24 43.52 0 69.12-12.8 28.16-35.84 53.76-66.56 71.68-58.88 35.84-130.56 28.16-156.16-12.8-10.24-20.48-10.24-43.52 0-69.12zM332.8 133.12c5.12-2.56 10.24-2.56 15.36-2.56 12.8 0 25.6 5.12 30.72 10.24 17.92 10.24 35.84 30.72 43.52 53.76 17.92 46.08 5.12 94.72-28.16 107.52-20.48 7.68-38.4 0-48.64-7.68-17.92-10.24-35.84-30.72-43.52-53.76-15.36-46.08 0-94.72 30.72-107.52z m576 647.68c0 76.8-58.88 140.8-130.56 140.8H245.76c-71.68 0-130.56-64-130.56-140.8v-256c0-76.8 58.88-140.8 130.56-140.8h133.12c5.12 0 12.8-2.56 17.92-5.12 10.24 0 17.92-2.56 25.6-5.12 25.6-10.24 43.52-25.6 58.88-48.64 25.6 30.72 66.56 51.2 110.08 53.76 5.12 2.56 10.24 2.56 15.36 2.56h168.96c71.68 0 130.56 64 130.56 140.8v258.56z"
              p-id="3660" fill="#8a8a8a"></path>
            <path
              d="M691.2 601.6H332.8c-20.48 0-38.4 17.92-38.4 38.4s17.92 38.4 38.4 38.4h358.4c20.48 0 38.4-17.92 38.4-38.4s-17.92-38.4-38.4-38.4z"
              p-id="3661" fill="#8a8a8a"></path>
          </svg>
        </dd>
        <dt>福利</dt>
      </dl>
      <dl>
        <dd>
          <svg t="1691114978090" class="icon" viewBox="0 0 1026 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
            p-id="2411" width="32" height="32">
            <path
              d="M1015.808 790.528q5.12 30.72-12.8 55.296t-48.64 29.696l-122.88 19.456q-29.696 5.12-54.784-12.8t-30.208-48.64l-104.448-661.504q-2.048-15.36 1.536-29.184t11.776-25.6 20.992-19.456 28.16-10.752l121.856-19.456q30.72-5.12 55.296 13.312t29.696 49.152zM500.736 63.488q30.72 0 52.224 21.504t21.504 52.224l0 684.032q0 30.72-21.504 52.224t-52.224 21.504l-106.496 0q-30.72 0-52.224-21.504t-21.504-52.224l0-684.032q0-30.72 16.384-52.224t48.128-21.504l115.712 0zM500.736 579.584q10.24 0 17.408-9.728t7.168-23.04q0-14.336-7.168-23.552t-17.408-9.216l-106.496 0q-10.24 0-17.408 9.216t-7.168 23.552q0 13.312 7.168 23.04t17.408 9.728l106.496 0zM500.736 449.536q10.24 0 17.408-9.728t7.168-24.064-7.168-23.552-17.408-9.216l-106.496 0q-10.24 0-17.408 9.216t-7.168 23.552 7.168 24.064 17.408 9.728l106.496 0zM179.2 63.488q30.72 0 52.736 21.504t22.016 52.224l0 684.032q0 30.72-22.016 52.224t-52.736 21.504l-106.496 0q-30.72 0-52.736-21.504t-22.016-52.224l0-684.032q0-30.72 22.016-52.224t52.736-21.504l106.496 0zM76.8 319.488q-11.264 0-18.432 9.216t-7.168 23.552q0 13.312 7.168 23.04t18.432 9.728l98.304 0q11.264 0 17.92-9.728t6.656-23.04q0-14.336-6.656-23.552t-17.92-9.216l-98.304 0zM179.2 641.024q11.264 0 17.92-9.216t6.656-22.528q0-14.336-6.656-23.04t-17.92-8.704l-102.4 0q-11.264 0-18.432 8.704t-7.168 23.04q0 13.312 7.168 22.528t18.432 9.216l102.4 0zM179.2 515.072q11.264 0 17.92-9.216t6.656-23.552-6.656-23.552-17.92-9.216l-102.4 0q-11.264 0-18.432 9.216t-7.168 23.552 7.168 23.552 18.432 9.216l102.4 0z"
              p-id="2412" fill="#8a8a8a"></path>
          </svg>
        </dd>
        <dt>书城</dt>
      </dl>
      <dl>
        <dd>
          <svg t="1691115021593" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
            p-id="3672" width="32" height="32">
            <path
              d="M541.636727 0q99.129741 0 186.506986 37.812375t152.271457 102.706587 102.706587 152.271457 37.812375 186.506986q0 100.151697-37.812375 187.528942t-102.706587 152.271457-152.271457 102.706587-186.506986 37.812375-186.506986-37.812375-152.271457-102.706587-102.706587-152.271457-37.812375-187.528942q0-99.129741 37.812375-186.506986t102.706587-152.271457 152.271457-102.706587 186.506986-37.812375zM672.447106 612.151697q3.065868-4.087824-3.065868-10.219561t-14.307385-13.796407-14.307385-15.840319-4.087824-15.329341q5.10978-16.351297 3.576846-24.015968t-9.708583-10.219561-23.50499-2.043912-36.790419 0.510978q-11.241517 0-18.39521 1.021956t-13.285429 1.532934-13.285429 1.021956-16.351297-0.510978q-14.307385-1.021956-21.972056-5.10978t-14.307385-8.175649-16.862275-7.153693-29.636727-4.087824q-27.592814-1.021956-39.345309-2.55489t-16.862275-3.065868-8.175649-2.043912-12.263473-0.510978q-9.197605 1.021956-28.103792 9.197605t-38.323353 18.906188-33.724551 21.972056-14.307385 18.39521q0 20.439122 2.55489 32.702595t7.153693 18.906188 9.708583 10.730539 10.219561 9.197605 13.796407 7.153693 18.906188 2.55489 18.906188 2.55489 13.796407 7.153693q10.219561 12.263473 21.461078 10.219561t19.928144-6.642715 14.307385-3.576846 6.642715 19.417166q0 8.175649 3.065868 12.263473t8.175649 6.131737l12.263473 6.131737q7.153693 4.087824 15.329341 11.241517 8.175649 8.175649 5.620758 15.329341t-7.664671 13.796407-9.708583 14.307385 0.510978 14.818363q7.153693 11.241517 15.329341 16.351297t15.840319 8.686627 13.796407 8.175649 8.175649 14.818363q0 3.065868 7.153693 11.752495t13.796407 17.884232 10.730539 15.329341-2.043912 5.10978q12.263473 2.043912 26.05988 2.043912t17.884232-5.10978l2.043912-2.043912 0-1.021956 3.065868-1.021956q2.043912-1.021956 5.620758-2.55489t9.708583-6.642715q12.263473-8.175649 23.50499-21.461078t19.417166-29.125749 13.796407-32.191617 7.664671-30.658683q2.043912-13.285429 6.642715-19.417166t8.175649-10.730539 6.131737-12.263473-0.510978-26.05988q-3.065868-23.50499 5.620758-34.235529t14.818363-17.884232zM773.620758 772.598802q14.307385-17.373253 14.818363-28.61477t-24.015968-17.373253q-25.548902-6.131737-36.279441-6.642715t-19.928144 10.730539-13.285429 22.994012 2.043912 32.191617q3.065868 9.197605 5.10978 14.818363t5.10978 7.153693 9.197605 1.021956 17.373253-3.576846q12.263473-3.065868 23.50499-14.307385t16.351297-18.39521zM801.213573 474.187625q7.153693-7.153693 24.015968-10.730539t34.235529-9.197605 30.658683-15.840319 14.307385-28.61477 0-33.724551-6.131737-30.658683-13.796407-32.191617-21.972056-38.323353q-14.307385-22.483034-26.05988-37.812375t-22.994012-26.05988-23.50499-19.417166-27.592814-17.884232q-16.351297-9.197605-32.191617-19.928144t-34.235529-14.307385-39.856287 4.598802-49.053892 35.768463l-17.373253 18.39521q-11.241517 10.219561-23.50499 19.417166t-23.50499 15.840319-20.439122 6.642715q-8.175649 0-25.548902 2.043912t-35.257485 10.219561-30.658683 22.994012-10.730539 39.345309q1.021956 27.592814 9.708583 35.768463t22.483034 9.197605 32.702595 2.043912 40.367265 13.285429q25.548902 6.131737 48.031936 12.263473 19.417166 5.10978 39.345309 12.774451t33.213573 15.840319q15.329341 9.197605 12.263473 24.015968t-10.730539 30.147705-12.774451 29.636727 6.131737 22.483034q15.329341 11.241517 22.483034 14.307385t15.329341 1.532934 22.483034-4.598802 43.944112-3.065868q-8.175649 0-3.065868-6.131737t15.840319-15.329341 22.994012-18.906188 20.439122-15.840319z"
              p-id="3673" fill="#8a8a8a"></path>
          </svg>
        </dd>
        <dt>听书</dt>
      </dl>
    </div>
  </div>
</template>

<script>
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
* {
  margin: 0;
  padding: 0;
  list-style: none;
  text-decoration: none;
}

html {
  font-size: 31.25px;
  overflow: hidden;
}

#app {
  position: relative;
  width: 12rem;
  height: 24rem;
  /* background-color: rgb(142, 191, 191); */
}

#top {
  position: absolute;
  width: 12rem;
  height: 10rem;
  text-align: center;
  top: 0;
  /* background-color: aqua; */
}

#content {
  position: absolute;
  top: 10rem;
  width: 12rem;
  height: 13.3rem;
  /* background-color: rgb(93, 95, 70); */
}

#buttom {
  position: fixed;
  bottom: 0;
  width: 12rem;
  height: 2.65rem;
  color: white;
  background-color: rgb(44, 64, 64);
}

#buttom dl {
  width: 32.5%;
  height: 100%;
  text-align: center;
  display: inline-block;
  /* background-color: aqua; */
}

dd {
  width: 6rem;
  height: 60%;
  margin: auto;
}

#top-content,
#top-top {
  width: 12rem;
  line-height: 3rem;
  height: 2rem;
}

#top-buttom {
  width: 11rem;
  margin: auto;
  margin-top: 0.8rem;
  height: 4.7rem;
  line-height: 4rem;
  background-color: rgb(114, 116, 122);
  border-radius: 0.6rem;
}

#top-buttom-top {
  width: 11rem;
  height: 1.5rem;
  line-height: 1.5rem;
  border-radius: 0.6rem 0.6rem 0 0;
  /* background-color: rgb(156, 35, 35); */
}

#top-buttom-buttom {
  width: 11rem;
  height: 3.2rem;
  /* background-color: beige; */
  border-radius: 0 0 0.6rem 0.6rem;
}

#text {
  background-color: rgb(238, 238, 238);
  width: 7.8rem;
  padding: 5px 50px;
  height: 1rem;
  border-radius: 45px;
  border: none;
}

student {
  width: 12rem;
  height: 100%;
}

.icon1 {
  position: absolute;
  left: 32px;
  top: 105px;
}

.icon {
  position: relative;
  top: 20px;
  left: -33px;
  margin: auto;
}

.w1 {
  width: 40px;
  height: 40px;

  background-color: aqua;
  float: left;
  margin-left: 10px;
  margin-top: 3px;
  border-radius: 20px;
}

.w2 {
  float: left;
  font-size: 15px;
  margin-left: 10px;
}

.w3 {
  float: left;
  color: rgb(203, 202, 202);
  font-size: 15px;
  margin-left: 10px;
}

.w4 {
  float: right;
  width: 50px;
  height: 35px;
  font-size: 15px;
  line-height: 35px;
  margin-top: 7px;
  border-radius: 20px 0 0 20px;
  background-color: rgb(209, 209, 209);
}

.yl1 {
  width: 12rem;
  height: 1rem;
  /* background-color: rgb(56, 106, 106); */
}

/* ::-webkit-scrollbar {
  display: none;
} */

.yl2 {
  width: 12rem;
  /* bottom: 3rem; */
  /* overflow: hidden;
  overflow-y: scroll; */
  /* background-color: antiquewhite; */
}



.yl1 li {
  float: left;
  width: 2.95rem;
  /* border: 1px solid black; */
  text-align: center;
  font-size: 25px;
  margin: auto;
}

#t1 {
  width: 2rem;
  height: 2rem;
  margin-left: 5px;
}

.w5 {
  width: 2rem;
  height: 2.7rem;
  margin-top: 5px;
  margin-left: 10px;
}

.ul-li1 {
  width: 11rem;
  height: 3rem;
  line-height: 1rem;
  margin: auto;
  margin: 20px;
}

.all1 {
  width: 2rem;
  height: 3rem;
}
</style>
